package com.example.demo.Controller;

import com.example.demo.entity.Resp;
import com.example.demo.pojo.Yh;
import com.example.demo.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;


@RestController
@CrossOrigin
public class Contoller {
    private List<Yh> list = new ArrayList<>();


    @Autowired
    private ILoginService iLoginService;

    @RequestMapping(value = "/yh",method = RequestMethod.GET)
    public List<Yh>find(){
        list.add(new Yh("1",
                "ERROR 1146 (42S02): Table 'dewu.dewu' doesn't exist"));
        list.add(new Yh("2","https://cdn.poizon.com/du_app/2020/image/32237308_byte820205byte_96b764f74b4212ee9c3058c8288ad7bf_iOS_w2252h3000.jpg?x-oss-process=image/format,webp"));
        list.add(new Yh("3","dfghjk"));
        list.add(new Yh("11","dfghjk"));
        list.add(new Yh("5","dfghjk"));
        list.add(new Yh("8","dfghjk"));

        return list;
    }

    @RequestMapping(value = "/upload",method = RequestMethod.POST)
    private Resp<String> upload(@RequestParam("file")MultipartFile file){
        return iLoginService.upload(file);
    }

}
