package com.example.demo.pojo;

import java.io.Serializable;

public class Yh  implements Serializable {
    private String id;
    private String lianjie;

    public Yh() {
    }

    public Yh(String id, String lianjie) {
        this.id = id;
        this.lianjie = lianjie;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLianjie() {
        return lianjie;
    }

    public void setLianjie(String lianjie) {
        this.lianjie = lianjie;
    }

    @Override
    public String toString() {
        return "Yh{" +
                "id='" + id + '\'' +
                ", lianjie='" + lianjie + '\'' +
                '}';
    }
}
