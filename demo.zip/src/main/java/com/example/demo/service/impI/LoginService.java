package com.example.demo.service.impI;

import com.example.demo.entity.Resp;
import com.example.demo.service.ILoginService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
@Service
public class LoginService implements ILoginService {

    @Override
    public Resp<String>upload(MultipartFile file){
        if(file.isEmpty()){
            return Resp.fail("400","文件为空！");
        }
        String OriginalFilename = file.getOriginalFilename();
        String fileName = System.currentTimeMillis()+"."+OriginalFilename.substring(OriginalFilename.lastIndexOf(".")+1);
        String filPath = "E:\\Ceshi\\";
        File dest = new File(filPath+fileName);
        if(!dest.getParentFile().exists())
            dest.getParentFile().mkdirs();
        try {
            file.transferTo(dest);
        }catch (Exception e){
            e.printStackTrace();
            return  Resp.fail("500","文件上传失败!");
        }
        return  Resp.success(fileName);
    }
}
