package com.example.demo.service;

import com.example.demo.entity.Resp;
import org.springframework.web.multipart.MultipartFile;

public interface ILoginService {
    Resp<String> upload (MultipartFile file);

}
